**********************************************************************
* _run_temp.do  --  Runner for SF1 build & analysis
**********************************************************************

clear all
set more off

global code "D:\MNEs_Trade\0_Code"

do "$code\_sf1_build_and_run.do"
