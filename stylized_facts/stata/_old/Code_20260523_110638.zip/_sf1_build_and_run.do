**********************************************************************
* _sf1_build_and_run.do
*
* STYLIZED FACT 1 -- MNE value-share in origin exports rises with
*                    origin GDP per capita.
*
* Measure throughout: MNE share in EXPORT VALUE (not firms, not obs).
* Three MNE definitions in parallel:
*   ext   = foreign subsidiary (parent != exporting country)
*   dom   = domestic MNE       (parent == exporting country)
*   total = any matched firm
*
* This do-file is self-contained:
*   1) runs 01_setup.do for globals
*   2) builds (and caches) $int\sf1_origin_value.dta from the raw
*      19 GB customs-ORBIS-DNB file -- keeping only the 5 columns
*      needed for SF1 -- if the cache does not already exist
*   3) produces graphs / table / regressions into $g_sf1, $t_sf1, $r_sf1
*      and mirrors to the Overleaf project under Stylized_Facts/SF1/
*
**********************************************************************

clear all
set more off

do "D:\MNEs_Trade\0_Code\01_setup.do"

* ---- SF1-specific output folders ----
global g_sf1     "$graphs\SF1_OriginShare"
global r_sf1     "$regs\SF1_OriginShare"
global t_sf1     "$tables\SF1_OriginShare"

global ol_sf      "$overleaf\Stylized_Facts"
global ol_g_sf1   "$ol_sf\Graphs\SF1_OriginShare"
global ol_r_sf1   "$ol_sf\Regressions\SF1_OriginShare"
global ol_t_sf1   "$ol_sf\Tables\SF1_OriginShare"

foreach dir in "$g_sf1" "$r_sf1" "$t_sf1" ///
               "$ol_sf" "$ol_sf\Graphs" "$ol_sf\Tables" "$ol_sf\Regressions" ///
               "$ol_g_sf1" "$ol_r_sf1" "$ol_t_sf1" {
    cap mkdir `"`dir'"'
}


**********************************************************************
* STEP 1 -- Build the SF1 origin-year cache (only if absent)
**********************************************************************

local cache "$int\sf1_origin_value.dta"

cap confirm file "`cache'"
if _rc != 0 {

    di as text _newline ">>> Building SF1 origin-year value cache from raw 19 GB file..."

    use country_orig year value_fob _merge_DNB_Orbis iso3_parent ///
        using "$customs\Base_final_Customs_DNB_Orbis_product_complete.dta", clear

    * Same sign correction as Part 0
    replace value_fob = -value_fob if value_fob < 0

    * Three MNE definitions (identical to Part 0 sec 0.2)
    gen byte MNE_ext   = (_merge_DNB_Orbis == 3) & (iso3_parent != "") ///
                       & (iso3_parent != country_orig)
    gen byte MNE_dom   = (_merge_DNB_Orbis == 3) & (iso3_parent == country_orig)
    gen byte MNE_total = (_merge_DNB_Orbis == 3)

    * Value contributions for each MNE definition
    gen double val_ext   = value_fob * MNE_ext
    gen double val_dom   = value_fob * MNE_dom
    gen double val_total = value_fob * MNE_total

    * Collapse to country-year totals
    gcollapse (sum) total_value=value_fob val_ext val_dom val_total, ///
              by(country_orig year)

    * Year-level value shares (per MNE def)
    gen double share_value_ext   = val_ext   / total_value
    gen double share_value_dom   = val_dom   / total_value
    gen double share_value_total = val_total / total_value

    label var total_value        "Total export value (origin-year)"
    label var val_ext            "Export value by foreign subsidiaries"
    label var val_dom            "Export value by domestic MNEs"
    label var val_total          "Export value by any matched MNE"
    label var share_value_ext    "Foreign-subsidiary share in export value"
    label var share_value_dom    "Domestic-MNE share in export value"
    label var share_value_total  "Any-MNE share in export value"

    * Merge in CEPII origin characteristics (gdpcap, pop, gdp)
    preserve
        use "$gravity\Gravity_V202211.dta", clear
        rename iso3_o country_orig
        keep country_orig year gdpcap_o pop_o gdp_o
        bysort country_orig year: keep if _n == 1
        gen ln_gdpcap_o = ln(gdpcap_o)
        gen ln_pop_o    = ln(pop_o)
        gen ln_gdp_o    = ln(gdp_o)
        label var ln_gdpcap_o "Log GDP per capita (origin)"
        label var ln_pop_o    "Log population (origin)"
        label var ln_gdp_o    "Log GDP (origin)"
        tempfile gravity_o
        save `gravity_o'
    restore

    merge m:1 country_orig year using `gravity_o', keep(1 3) nogen

    * Origin FE id
    egen orig_id = group(country_orig)

    compress
    save "`cache'", replace
    di as text ">>> Cache saved to `cache'"
}

use "`cache'", clear

* ---- Apply project-wide origin exclusions (see 01_setup.do) ----
drop if inlist(country_orig, $excluded_origins)

qui count
di as text ">>> SF1 cache loaded (post-exclusions): " r(N) " origin-year observations."
qui levelsof country_orig, local(cs) clean
di as text ">>> Origins kept:   `cs'"
qui sum year
di as text ">>> Year range: " %4.0f r(min) " - " %4.0f r(max)


**********************************************************************
* STEP 2 -- DESCRIPTIVE TABLE
*           Pooled-value MNE share per country, three definitions
**********************************************************************

preserve
    * Pooled across years: build totals first, then ratios (value-weighted).
    gcollapse (sum) total_value val_ext val_dom val_total ///
              (mean) ln_gdpcap_o ln_pop_o ln_gdp_o, ///
              by(country_orig)
    gen double sh_ext   = val_ext   / total_value
    gen double sh_dom   = val_dom   / total_value
    gen double sh_total = val_total / total_value

    label var sh_ext   "MNE\$_{\text{ext}}\$ share"
    label var sh_dom   "MNE\$_{\text{dom}}\$ share"
    label var sh_total "MNE\$_{\text{total}}\$ share"

    gsort -sh_total

    * Manual LaTeX fragment so format is exactly what we want
    file open fh using "$t_sf1\tab_sf1_share_by_country.tex", write replace
    file write fh "\begin{tabular}{lcccc}" _n
    file write fh "\toprule" _n
    file write fh " & MNE\$_{\text{total}}\$ & MNE\$_{\text{ext}}\$ & MNE\$_{\text{dom}}\$ & ln GDP/cap \\" _n
    file write fh "Country & share (value) & share (value) & share (value) & (origin, mean) \\" _n
    file write fh "\midrule" _n
    forvalues i = 1/`=_N' {
        local cc = country_orig[`i']
        local v1 : di %5.3f sh_total[`i']
        local v2 : di %5.3f sh_ext[`i']
        local v3 : di %5.3f sh_dom[`i']
        local v4 : di %5.2f ln_gdpcap_o[`i']
        file write fh "`cc' & `v1' & `v2' & `v3' & `v4' \\" _n
    }
    file write fh "\bottomrule" _n
    file write fh "\end{tabular}" _n
    file close fh

    cap copy "$t_sf1\tab_sf1_share_by_country.tex" ///
             "$ol_t_sf1\tab_sf1_share_by_country.tex", replace

    * Save the cross-section for the figures step
    tempfile cross
    save `cross'
restore


**********************************************************************
* STEP 3 -- FIGURES (cross-sectional, pooled across years)
**********************************************************************

use `cross', clear

* ---- 3.A  Bar chart: MNE value share by country, ranked, three defs ----

* Main: overlaid bars ranked by total
gsort -sh_total
gen rank = _n
labmask rank, values(country_orig)
local N = _N
twoway ///
    (bar sh_total rank, barwidth(0.85) fcolor($c_MNEtot) lcolor($c_MNEtot)) ///
    (bar sh_ext   rank, barwidth(0.55) fcolor($c_MNE)    lcolor($c_MNE)) ///
    (bar sh_dom   rank, barwidth(0.25) fcolor($c_MNEdom) lcolor($c_MNEdom)), ///
    ytitle("MNE share in export value") xtitle("") ///
    xla(1/`N', valuelabel ang(45) noticks labsize(*0.9)) ///
    ylab(0(0.1)1, nogrid format(%9.1f)) ///
    legend(order(1 "MNE_total" 2 "MNE_ext (foreign)" 3 "MNE_dom") ///
           position(6) rows(1) region(lcolor(white)) size(small)) ///
    $gro
export_graph "fig_sf1_bar_overlay" "$g_sf1" "$ol_g_sf1"

* Per-definition bars
foreach def in ext dom total {
    if "`def'" == "ext"   local col "$c_MNE"
    if "`def'" == "dom"   local col "$c_MNEdom"
    if "`def'" == "total" local col "$c_MNEtot"
    cap drop rank
    gsort -sh_`def'
    gen rank = _n
    labmask rank, values(country_orig)
    twoway (bar sh_`def' rank, barwidth(0.7) fcolor(`col') lcolor(`col')), ///
        ytitle("MNE_`def' share in export value") xtitle("") ///
        xla(1/`N', valuelabel ang(45) noticks labsize(*0.9)) ///
        ylab(, nogrid format(%9.1f)) $gro
    export_graph "fig_sf1_bar_`def'" "$g_sf1" "$ol_g_sf1"
}

* ---- 3.B  Scatter: share vs ln GDP per capita (origin), one per def ----

foreach def in ext dom total {
    if "`def'" == "ext"   local col "$c_MNE"
    if "`def'" == "dom"   local col "$c_MNEdom"
    if "`def'" == "total" local col "$c_MNEtot"
    twoway ///
        (lfitci sh_`def' ln_gdpcap_o, lcolor(black) acolor(gs14)) ///
        (scatter sh_`def' ln_gdpcap_o, mlabel(country_orig) ///
            mlabsize(2.8) mlabposition(3) ///
            msize(*1.4) mcolor(`col') mlabcolor(`col') ms(O)), ///
        ytitle("MNE_`def' share in export value") ///
        xtitle("Log GDP per capita (origin)") ///
        ylab(, nogrid) legend(off) $gro
    export_graph "fig_sf1_scatter_`def'" "$g_sf1" "$ol_g_sf1"
}

* Combined scatter (all 3 defs on one panel)
twoway ///
    (lfit    sh_total ln_gdpcap_o, lcolor($c_MNEtot)) ///
    (scatter sh_total ln_gdpcap_o, mlabel(country_orig) ///
        mlabsize(2.4) mlabposition(3) ///
        msize(*1.1) mcolor($c_MNEtot) mlabcolor($c_MNEtot) ms(O)) ///
    (lfit    sh_ext   ln_gdpcap_o, lcolor($c_MNE)) ///
    (scatter sh_ext   ln_gdpcap_o, mlabel(country_orig) ///
        mlabsize(2.4) mlabposition(9) ///
        msize(*1.1) mcolor($c_MNE) mlabcolor($c_MNE) ms(D)) ///
    (lfit    sh_dom   ln_gdpcap_o, lcolor($c_MNEdom)) ///
    (scatter sh_dom   ln_gdpcap_o, mlabel(country_orig) ///
        mlabsize(2.4) mlabposition(6) ///
        msize(*1.1) mcolor($c_MNEdom) mlabcolor($c_MNEdom) ms(T)), ///
    ytitle("MNE share in export value") ///
    xtitle("Log GDP per capita (origin)") ///
    ylab(, nogrid format(%9.1f)) ///
    legend(order(2 "MNE_total" 4 "MNE_ext (foreign)" 6 "MNE_dom") ///
           position(6) rows(1) region(lcolor(white)) size(small)) $gro
export_graph "fig_sf1_scatter_combined" "$g_sf1" "$ol_g_sf1"


**********************************************************************
* STEP 4 -- REGRESSIONS (country-year panel)
*
*   For each MNE definition, regress the value-share on ln_gdpcap_o
*   with progressively richer specifications.
*   With only 10 origin clusters we use robust SE (origin-clustered SE
*   would be small-sample biased).
**********************************************************************

use "`cache'", clear
drop if inlist(country_orig, $excluded_origins)

* For each MNE def, one .tex file with 4 columns of robustness.
foreach def in ext dom total {

    local dv "share_value_`def'"
    local outfile "$r_sf1\reg_sf1_`def'.tex"

    * Col 1: pooled OLS, robust SE
    reg `dv' ln_gdpcap_o, robust
    outreg2 using "`outfile'", replace tex(frag) label ctitle("OLS") ///
        addtext(Year FE, No, Pop control, No, SE, Robust) dec(4)

    * Col 2: + ln population
    reg `dv' ln_gdpcap_o ln_pop_o, robust
    outreg2 using "`outfile'", append tex(frag) label ctitle("+ ln pop") ///
        addtext(Year FE, No, Pop control, Yes, SE, Robust) dec(4)

    * Col 3: year FE only
    reghdfe `dv' ln_gdpcap_o, absorb(year) vce(robust)
    outreg2 using "`outfile'", append tex(frag) label ctitle("Year FE") ///
        addtext(Year FE, Yes, Pop control, No, SE, Robust) dec(4)

    * Col 4: year FE + pop
    reghdfe `dv' ln_gdpcap_o ln_pop_o, absorb(year) vce(robust)
    outreg2 using "`outfile'", append tex(frag) label ctitle("Year FE + pop") ///
        addtext(Year FE, Yes, Pop control, Yes, SE, Robust) dec(4)

    cap copy "`outfile'" "$ol_r_sf1\reg_sf1_`def'.tex", replace
}


**********************************************************************
* DONE
**********************************************************************
di as text ""
di as text "==========================================================="
di as text "  SF1 outputs written:"
di as text "    Graphs       -> $g_sf1"
di as text "    Tables       -> $t_sf1"
di as text "    Regressions  -> $r_sf1"
di as text "    Overleaf mirror -> $ol_sf"
di as text "==========================================================="
